package com.maine.ankosqlite

data class MobileCourse(val title: String, val time: Int)

object MobileCourseTable {
    val NAME = "MobileCourse"
    val ID = "_id"
    val TITLE = "title"
    val TIME = "time"
}